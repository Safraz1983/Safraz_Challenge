﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace XyiconLK.CodingChallenge.DataAccess.Configuraion
{
    
    public class DataAccessConfigurations
    {
        public static string ConnectionString { get; set; }
        public static string GetConnectionString()
        {
            
            try
            {
                var configuraionList = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.json").Build().GetSection("ConnectionStrings");

                ConnectionString = configuraionList["ConnectionStringOne"].ToString();
            }
            catch (Exception ex)
            {

                LogWriter.LogWriter.LogWrite("Error :" + ex);
            }

            return ConnectionString;
        }

    }
}
