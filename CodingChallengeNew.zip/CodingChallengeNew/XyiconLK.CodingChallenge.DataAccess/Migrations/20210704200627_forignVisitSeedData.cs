﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XyiconLK.CodingChallenge.DataAccess.Migrations
{
    public partial class forignVisitSeedData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "310");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "311");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "312");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "313");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "314");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "315");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "316");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "317");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "318");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "319");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "320");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "321");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "322");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "323");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "324");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "325");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "326");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "327");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "328");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "329");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "330");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "331");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "332");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "333");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "334");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "335");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "336");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "337");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "338");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "339");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "340");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "341");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "342");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "343");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "344");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "345");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "346");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "347");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "348");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "349");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "350");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "351");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "352");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "353");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "354");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "355");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "356");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "357");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "358");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "359");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "360");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "361");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "362");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "363");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "364");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "365");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "366");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "367");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "368");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "369");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "370");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "371");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "372");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "373");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "374");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "375");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "376");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "377");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "378");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "379");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "380");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "381");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "382");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "383");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "384");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "385");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "386");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "387");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "388");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "389");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "390");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "391");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "392");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "393");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "394");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "395");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "396");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "397");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "398");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "399");

            migrationBuilder.DropColumn(
                name: "CreatedDate",
                table: "ForeignVisit");

            migrationBuilder.InsertData(
                table: "ForeignVisit",
                columns: new[] { "ID", "Active", "City", "Country", "CreatedBy", "CreatedOn", "PersonID", "VisitedYear" },
                values: new object[] { 1, true, "CMB", "SLK", 100, new DateTime(2021, 7, 5, 1, 36, 23, 995, DateTimeKind.Local).AddTicks(7980), 1, 2019 });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "30",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 30", 48, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8313), 130, "7/5/2021 1:36:23 AM", "abcd30@gmail.com", "ABCD30", "OLSTNM30", "0213412330" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "31",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 31", 49, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8434), 131, "7/5/2021 1:36:23 AM", "abcd31@gmail.com", "ABCD31", "OLSTNM31", "0213412331" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "32",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 32", 50, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8552), 132, "7/5/2021 1:36:23 AM", "abcd32@gmail.com", "ABCD32", "OLSTNM32", "0213412332" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "33",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 33", 51, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8672), 133, "7/5/2021 1:36:23 AM", "abcd33@gmail.com", "ABCD33", "OLSTNM33", "0213412333" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "34",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 34", 52, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(9616), 134, "7/5/2021 1:36:23 AM", "abcd34@gmail.com", "ABCD34", "OLSTNM34", "0213412334" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "35",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 35", 53, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(9857), 135, "7/5/2021 1:36:23 AM", "abcd35@gmail.com", "ABCD35", "OLSTNM35", "0213412335" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "36",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 36", 54, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5), 136, "7/5/2021 1:36:23 AM", "abcd36@gmail.com", "ABCD36", "OLSTNM36", "0213412336" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "37",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 37", 55, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(135), 137, "7/5/2021 1:36:23 AM", "abcd37@gmail.com", "ABCD37", "OLSTNM37", "0213412337" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "38",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 38", 56, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(276), 138, "7/5/2021 1:36:23 AM", "abcd38@gmail.com", "ABCD38", "OLSTNM38", "0213412338" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "39",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 39", 57, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(415), 139, "7/5/2021 1:36:23 AM", "abcd39@gmail.com", "ABCD39", "OLSTNM39", "0213412339" });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "11", true, "address 11", 29, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(5365), 111, "7/5/2021 1:36:23 AM", "abcd11@gmail.com", "ABCD11", "MLDS1", null, "OLSTNM11", "0213412311" },
                    { "84", true, "address 84", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7687), 184, "7/5/2021 1:36:23 AM", "abcd84@gmail.com", "ABCD84", "MLDS1", null, "OLSTNM84", "0213412384" },
                    { "83", true, "address 83", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7561), 183, "7/5/2021 1:36:23 AM", "abcd83@gmail.com", "ABCD83", "MLDS1", null, "OLSTNM83", "0213412383" },
                    { "82", true, "address 82", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7412), 182, "7/5/2021 1:36:23 AM", "abcd82@gmail.com", "ABCD82", "MLDS1", null, "OLSTNM82", "0213412382" },
                    { "81", true, "address 81", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7269), 181, "7/5/2021 1:36:23 AM", "abcd81@gmail.com", "ABCD81", "MLDS1", null, "OLSTNM81", "0213412381" },
                    { "80", true, "address 80", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7124), 180, "7/5/2021 1:36:23 AM", "abcd80@gmail.com", "ABCD80", "MLDS1", null, "OLSTNM80", "0213412380" },
                    { "79", true, "address 79", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6973), 179, "7/5/2021 1:36:23 AM", "abcd79@gmail.com", "ABCD79", "MLDS1", null, "OLSTNM79", "0213412379" },
                    { "78", true, "address 78", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6822), 178, "7/5/2021 1:36:23 AM", "abcd78@gmail.com", "ABCD78", "MLDS1", null, "OLSTNM78", "0213412378" },
                    { "77", true, "address 77", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6660), 177, "7/5/2021 1:36:23 AM", "abcd77@gmail.com", "ABCD77", "MLDS1", null, "OLSTNM77", "0213412377" },
                    { "85", true, "address 85", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(7938), 185, "7/5/2021 1:36:23 AM", "abcd85@gmail.com", "ABCD85", "MLDS1", null, "OLSTNM85", "0213412385" },
                    { "76", true, "address 76", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6471), 176, "7/5/2021 1:36:23 AM", "abcd76@gmail.com", "ABCD76", "MLDS1", null, "OLSTNM76", "0213412376" },
                    { "74", true, "address 74", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6103), 174, "7/5/2021 1:36:23 AM", "abcd74@gmail.com", "ABCD74", "MLDS1", null, "OLSTNM74", "0213412374" },
                    { "73", true, "address 73", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5957), 173, "7/5/2021 1:36:23 AM", "abcd73@gmail.com", "ABCD73", "MLDS1", null, "OLSTNM73", "0213412373" },
                    { "72", true, "address 72", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5809), 172, "7/5/2021 1:36:23 AM", "abcd72@gmail.com", "ABCD72", "MLDS1", null, "OLSTNM72", "0213412372" },
                    { "71", true, "address 71", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5659), 171, "7/5/2021 1:36:23 AM", "abcd71@gmail.com", "ABCD71", "MLDS1", null, "OLSTNM71", "0213412371" },
                    { "70", true, "address 70", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5501), 170, "7/5/2021 1:36:23 AM", "abcd70@gmail.com", "ABCD70", "MLDS1", null, "OLSTNM70", "0213412370" },
                    { "69", true, "address 69", 87, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5350), 169, "7/5/2021 1:36:23 AM", "abcd69@gmail.com", "ABCD69", "MLDS1", null, "OLSTNM69", "0213412369" },
                    { "68", true, "address 68", 86, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(5180), 168, "7/5/2021 1:36:23 AM", "abcd68@gmail.com", "ABCD68", "MLDS1", null, "OLSTNM68", "0213412368" },
                    { "67", true, "address 67", 85, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4826), 167, "7/5/2021 1:36:23 AM", "abcd67@gmail.com", "ABCD67", "MLDS1", null, "OLSTNM67", "0213412367" },
                    { "75", true, "address 75", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(6249), 175, "7/5/2021 1:36:23 AM", "abcd75@gmail.com", "ABCD75", "MLDS1", null, "OLSTNM75", "0213412375" },
                    { "86", true, "address 86", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8098), 186, "7/5/2021 1:36:23 AM", "abcd86@gmail.com", "ABCD86", "MLDS1", null, "OLSTNM86", "0213412386" },
                    { "87", true, "address 87", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8240), 187, "7/5/2021 1:36:23 AM", "abcd87@gmail.com", "ABCD87", "MLDS1", null, "OLSTNM87", "0213412387" },
                    { "88", true, "address 88", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8388), 188, "7/5/2021 1:36:23 AM", "abcd88@gmail.com", "ABCD88", "MLDS1", null, "OLSTNM88", "0213412388" },
                    { "1", true, "address 1", 19, new DateTime(2021, 7, 5, 1, 36, 23, 972, DateTimeKind.Local).AddTicks(9670), 101, "7/5/2021 1:36:23 AM", "abcd1@gmail.com", "ABCD1", "MLDS1", null, "OLSTNM1", "021341231" },
                    { "2", true, "address 2", 20, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(2647), 102, "7/5/2021 1:36:23 AM", "abcd2@gmail.com", "ABCD2", "MLDS1", null, "OLSTNM2", "021341232" },
                    { "3", true, "address 3", 21, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(3540), 103, "7/5/2021 1:36:23 AM", "abcd3@gmail.com", "ABCD3", "MLDS1", null, "OLSTNM3", "021341233" },
                    { "4", true, "address 4", 22, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(3729), 104, "7/5/2021 1:36:23 AM", "abcd4@gmail.com", "ABCD4", "MLDS1", null, "OLSTNM4", "021341234" },
                    { "5", true, "address 5", 23, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(3847), 105, "7/5/2021 1:36:23 AM", "abcd5@gmail.com", "ABCD5", "MLDS1", null, "OLSTNM5", "021341235" },
                    { "6", true, "address 6", 24, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(3986), 106, "7/5/2021 1:36:23 AM", "abcd6@gmail.com", "ABCD6", "MLDS1", null, "OLSTNM6", "021341236" },
                    { "7", true, "address 7", 25, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(4250), 107, "7/5/2021 1:36:23 AM", "abcd7@gmail.com", "ABCD7", "MLDS1", null, "OLSTNM7", "021341237" },
                    { "8", true, "address 8", 26, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(4587), 108, "7/5/2021 1:36:23 AM", "abcd8@gmail.com", "ABCD8", "MLDS1", null, "OLSTNM8", "021341238" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "99", true, "address 99", 32, new DateTime(2021, 7, 5, 1, 36, 23, 995, DateTimeKind.Local).AddTicks(332), 199, "7/5/2021 1:36:23 AM", "abcd99@gmail.com", "ABCD99", "MLDS1", null, "OLSTNM99", "0213412399" },
                    { "98", true, "address 98", 32, new DateTime(2021, 7, 5, 1, 36, 23, 995, DateTimeKind.Local).AddTicks(103), 198, "7/5/2021 1:36:23 AM", "abcd98@gmail.com", "ABCD98", "MLDS1", null, "OLSTNM98", "0213412398" },
                    { "97", true, "address 97", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9942), 197, "7/5/2021 1:36:23 AM", "abcd97@gmail.com", "ABCD97", "MLDS1", null, "OLSTNM97", "0213412397" },
                    { "96", true, "address 96", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9787), 196, "7/5/2021 1:36:23 AM", "abcd96@gmail.com", "ABCD96", "MLDS1", null, "OLSTNM96", "0213412396" },
                    { "95", true, "address 95", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9645), 195, "7/5/2021 1:36:23 AM", "abcd95@gmail.com", "ABCD95", "MLDS1", null, "OLSTNM95", "0213412395" },
                    { "94", true, "address 94", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9484), 194, "7/5/2021 1:36:23 AM", "abcd94@gmail.com", "ABCD94", "MLDS1", null, "OLSTNM94", "0213412394" },
                    { "93", true, "address 93", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9292), 193, "7/5/2021 1:36:23 AM", "abcd93@gmail.com", "ABCD93", "MLDS1", null, "OLSTNM93", "0213412393" },
                    { "92", true, "address 92", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(9048), 192, "7/5/2021 1:36:23 AM", "abcd92@gmail.com", "ABCD92", "MLDS1", null, "OLSTNM92", "0213412392" },
                    { "91", true, "address 91", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8880), 191, "7/5/2021 1:36:23 AM", "abcd91@gmail.com", "ABCD91", "MLDS1", null, "OLSTNM91", "0213412391" },
                    { "90", true, "address 90", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8693), 190, "7/5/2021 1:36:23 AM", "abcd90@gmail.com", "ABCD90", "MLDS1", null, "OLSTNM90", "0213412390" },
                    { "89", true, "address 89", 32, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(8542), 189, "7/5/2021 1:36:23 AM", "abcd89@gmail.com", "ABCD89", "MLDS1", null, "OLSTNM89", "0213412389" },
                    { "66", true, "address 66", 84, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4699), 166, "7/5/2021 1:36:23 AM", "abcd66@gmail.com", "ABCD66", "MLDS1", null, "OLSTNM66", "0213412366" },
                    { "10", true, "address 10", 28, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(5175), 110, "7/5/2021 1:36:23 AM", "abcd10@gmail.com", "ABCD10", "MLDS1", null, "OLSTNM10", "0213412310" },
                    { "65", true, "address 65", 83, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4553), 165, "7/5/2021 1:36:23 AM", "abcd65@gmail.com", "ABCD65", "MLDS1", null, "OLSTNM65", "0213412365" },
                    { "63", true, "address 63", 81, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4270), 163, "7/5/2021 1:36:23 AM", "abcd63@gmail.com", "ABCD63", "MLDS1", null, "OLSTNM63", "0213412363" },
                    { "29", true, "address 29", 47, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8198), 129, "7/5/2021 1:36:23 AM", "abcd29@gmail.com", "ABCD29", "MLDS1", null, "OLSTNM29", "0213412329" },
                    { "28", true, "address 28", 46, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(8078), 128, "7/5/2021 1:36:23 AM", "abcd28@gmail.com", "ABCD28", "MLDS1", null, "OLSTNM28", "0213412328" },
                    { "27", true, "address 27", 45, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7955), 127, "7/5/2021 1:36:23 AM", "abcd27@gmail.com", "ABCD27", "MLDS1", null, "OLSTNM27", "0213412327" },
                    { "26", true, "address 26", 44, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7804), 126, "7/5/2021 1:36:23 AM", "abcd26@gmail.com", "ABCD26", "MLDS1", null, "OLSTNM26", "0213412326" },
                    { "25", true, "address 25", 43, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7565), 125, "7/5/2021 1:36:23 AM", "abcd25@gmail.com", "ABCD25", "MLDS1", null, "OLSTNM25", "0213412325" },
                    { "24", true, "address 24", 42, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7435), 124, "7/5/2021 1:36:23 AM", "abcd24@gmail.com", "ABCD24", "MLDS1", null, "OLSTNM24", "0213412324" },
                    { "23", true, "address 23", 41, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7298), 123, "7/5/2021 1:36:23 AM", "abcd23@gmail.com", "ABCD23", "MLDS1", null, "OLSTNM23", "0213412323" },
                    { "22", true, "address 22", 40, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7158), 122, "7/5/2021 1:36:23 AM", "abcd22@gmail.com", "ABCD22", "MLDS1", null, "OLSTNM22", "0213412322" },
                    { "40", true, "address 40", 58, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(553), 140, "7/5/2021 1:36:23 AM", "abcd40@gmail.com", "ABCD40", "MLDS1", null, "OLSTNM40", "0213412340" },
                    { "21", true, "address 21", 39, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(7024), 121, "7/5/2021 1:36:23 AM", "abcd21@gmail.com", "ABCD21", "MLDS1", null, "OLSTNM21", "0213412321" },
                    { "19", true, "address 19", 37, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6735), 119, "7/5/2021 1:36:23 AM", "abcd19@gmail.com", "ABCD19", "MLDS1", null, "OLSTNM19", "0213412319" },
                    { "18", true, "address 18", 36, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6565), 118, "7/5/2021 1:36:23 AM", "abcd18@gmail.com", "ABCD18", "MLDS1", null, "OLSTNM18", "0213412318" },
                    { "17", true, "address 17", 35, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6311), 117, "7/5/2021 1:36:23 AM", "abcd17@gmail.com", "ABCD17", "MLDS1", null, "OLSTNM17", "0213412317" },
                    { "16", true, "address 16", 34, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6186), 116, "7/5/2021 1:36:23 AM", "abcd16@gmail.com", "ABCD16", "MLDS1", null, "OLSTNM16", "0213412316" },
                    { "15", true, "address 15", 33, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6049), 115, "7/5/2021 1:36:23 AM", "abcd15@gmail.com", "ABCD15", "MLDS1", null, "OLSTNM15", "0213412315" },
                    { "14", true, "address 14", 32, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(5910), 114, "7/5/2021 1:36:23 AM", "abcd14@gmail.com", "ABCD14", "MLDS1", null, "OLSTNM14", "0213412314" },
                    { "13", true, "address 13", 31, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(5761), 113, "7/5/2021 1:36:23 AM", "abcd13@gmail.com", "ABCD13", "MLDS1", null, "OLSTNM13", "0213412313" },
                    { "12", true, "address 12", 30, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(5566), 112, "7/5/2021 1:36:23 AM", "abcd12@gmail.com", "ABCD12", "MLDS1", null, "OLSTNM12", "0213412312" },
                    { "20", true, "address 20", 38, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(6882), 120, "7/5/2021 1:36:23 AM", "abcd20@gmail.com", "ABCD20", "MLDS1", null, "OLSTNM20", "0213412320" },
                    { "41", true, "address 41", 59, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(694), 141, "7/5/2021 1:36:23 AM", "abcd41@gmail.com", "ABCD41", "MLDS1", null, "OLSTNM41", "0213412341" },
                    { "42", true, "address 42", 60, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(839), 142, "7/5/2021 1:36:23 AM", "abcd42@gmail.com", "ABCD42", "MLDS1", null, "OLSTNM42", "0213412342" },
                    { "43", true, "address 43", 61, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1076), 143, "7/5/2021 1:36:23 AM", "abcd43@gmail.com", "ABCD43", "MLDS1", null, "OLSTNM43", "0213412343" },
                    { "62", true, "address 62", 80, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4076), 162, "7/5/2021 1:36:23 AM", "abcd62@gmail.com", "ABCD62", "MLDS1", null, "OLSTNM62", "0213412362" },
                    { "61", true, "address 61", 79, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3924), 161, "7/5/2021 1:36:23 AM", "abcd61@gmail.com", "ABCD61", "MLDS1", null, "OLSTNM61", "0213412361" },
                    { "60", true, "address 60", 78, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3744), 160, "7/5/2021 1:36:23 AM", "abcd60@gmail.com", "ABCD60", "MLDS1", null, "OLSTNM60", "0213412360" },
                    { "9", true, "address 9", 27, new DateTime(2021, 7, 5, 1, 36, 23, 993, DateTimeKind.Local).AddTicks(4783), 109, "7/5/2021 1:36:23 AM", "abcd9@gmail.com", "ABCD9", "MLDS1", null, "OLSTNM9", "021341239" },
                    { "58", true, "address 58", 76, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3359), 158, "7/5/2021 1:36:23 AM", "abcd58@gmail.com", "ABCD58", "MLDS1", null, "OLSTNM58", "0213412358" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "57", true, "address 57", 75, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3222), 157, "7/5/2021 1:36:23 AM", "abcd57@gmail.com", "ABCD57", "MLDS1", null, "OLSTNM57", "0213412357" },
                    { "56", true, "address 56", 74, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3094), 156, "7/5/2021 1:36:23 AM", "abcd56@gmail.com", "ABCD56", "MLDS1", null, "OLSTNM56", "0213412356" },
                    { "55", true, "address 55", 73, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2974), 155, "7/5/2021 1:36:23 AM", "abcd55@gmail.com", "ABCD55", "MLDS1", null, "OLSTNM55", "0213412355" },
                    { "54", true, "address 54", 72, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2850), 154, "7/5/2021 1:36:23 AM", "abcd54@gmail.com", "ABCD54", "MLDS1", null, "OLSTNM54", "0213412354" },
                    { "53", true, "address 53", 71, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2721), 153, "7/5/2021 1:36:23 AM", "abcd53@gmail.com", "ABCD53", "MLDS1", null, "OLSTNM53", "0213412353" },
                    { "52", true, "address 52", 70, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2557), 152, "7/5/2021 1:36:23 AM", "abcd52@gmail.com", "ABCD52", "MLDS1", null, "OLSTNM52", "0213412352" },
                    { "51", true, "address 51", 69, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2297), 151, "7/5/2021 1:36:23 AM", "abcd51@gmail.com", "ABCD51", "MLDS1", null, "OLSTNM51", "0213412351" },
                    { "50", true, "address 50", 68, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2151), 150, "7/5/2021 1:36:23 AM", "abcd50@gmail.com", "ABCD50", "MLDS1", null, "OLSTNM50", "0213412350" },
                    { "49", true, "address 49", 67, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(2003), 149, "7/5/2021 1:36:23 AM", "abcd49@gmail.com", "ABCD49", "MLDS1", null, "OLSTNM49", "0213412349" },
                    { "48", true, "address 48", 66, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1859), 148, "7/5/2021 1:36:23 AM", "abcd48@gmail.com", "ABCD48", "MLDS1", null, "OLSTNM48", "0213412348" },
                    { "47", true, "address 47", 65, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1708), 147, "7/5/2021 1:36:23 AM", "abcd47@gmail.com", "ABCD47", "MLDS1", null, "OLSTNM47", "0213412347" },
                    { "46", true, "address 46", 64, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1547), 146, "7/5/2021 1:36:23 AM", "abcd46@gmail.com", "ABCD46", "MLDS1", null, "OLSTNM46", "0213412346" },
                    { "45", true, "address 45", 63, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1397), 145, "7/5/2021 1:36:23 AM", "abcd45@gmail.com", "ABCD45", "MLDS1", null, "OLSTNM45", "0213412345" },
                    { "44", true, "address 44", 62, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(1246), 144, "7/5/2021 1:36:23 AM", "abcd44@gmail.com", "ABCD44", "MLDS1", null, "OLSTNM44", "0213412344" },
                    { "64", true, "address 64", 82, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(4425), 164, "7/5/2021 1:36:23 AM", "abcd64@gmail.com", "ABCD64", "MLDS1", null, "OLSTNM64", "0213412364" },
                    { "59", true, "address 59", 77, new DateTime(2021, 7, 5, 1, 36, 23, 994, DateTimeKind.Local).AddTicks(3491), 159, "7/5/2021 1:36:23 AM", "abcd59@gmail.com", "ABCD59", "MLDS1", null, "OLSTNM59", "0213412359" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ForeignVisit",
                keyColumn: "ID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "1");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "10");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "11");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "12");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "13");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "14");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "15");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "16");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "17");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "18");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "19");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "2");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "20");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "21");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "22");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "23");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "24");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "25");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "26");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "27");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "28");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "29");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "3");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "4");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "40");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "41");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "42");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "43");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "44");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "45");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "46");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "47");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "48");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "49");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "5");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "50");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "51");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "52");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "53");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "54");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "55");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "56");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "57");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "58");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "59");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "6");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "60");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "61");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "62");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "63");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "64");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "65");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "66");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "67");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "68");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "69");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "7");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "70");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "71");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "72");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "73");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "74");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "75");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "76");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "77");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "78");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "79");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "8");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "80");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "81");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "82");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "83");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "84");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "85");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "86");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "87");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "88");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "89");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "9");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "90");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "91");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "92");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "93");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "94");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "95");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "96");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "97");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "98");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "99");

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDate",
                table: "ForeignVisit",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "30",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 0", 18, new DateTime(2021, 7, 4, 22, 19, 40, 128, DateTimeKind.Local).AddTicks(991), 100, "7/4/2021 10:19:40 PM", "abcd0@gmail.com", "ABCD0", "OLSTNM0", "021341230" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "31",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 1", 19, new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9269), 101, "7/4/2021 10:19:40 PM", "abcd1@gmail.com", "ABCD1", "OLSTNM1", "021341231" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "32",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 2", 20, new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9790), 102, "7/4/2021 10:19:40 PM", "abcd2@gmail.com", "ABCD2", "OLSTNM2", "021341232" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "33",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 3", 21, new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9874), 103, "7/4/2021 10:19:40 PM", "abcd3@gmail.com", "ABCD3", "OLSTNM3", "021341233" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "34",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 4", 22, new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9939), 104, "7/4/2021 10:19:40 PM", "abcd4@gmail.com", "ABCD4", "OLSTNM4", "021341234" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "35",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 5", 23, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(15), 105, "7/4/2021 10:19:40 PM", "abcd5@gmail.com", "ABCD5", "OLSTNM5", "021341235" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "36",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 6", 24, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(77), 106, "7/4/2021 10:19:40 PM", "abcd6@gmail.com", "ABCD6", "OLSTNM6", "021341236" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "37",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 7", 25, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(275), 107, "7/4/2021 10:19:40 PM", "abcd7@gmail.com", "ABCD7", "OLSTNM7", "021341237" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "38",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 8", 26, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(352), 108, "7/4/2021 10:19:40 PM", "abcd8@gmail.com", "ABCD8", "OLSTNM8", "021341238" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "39",
                columns: new[] { "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "LastName", "PhoneNumber" },
                values: new object[] { "address 9", 27, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(418), 109, "7/4/2021 10:19:40 PM", "abcd9@gmail.com", "ABCD9", "OLSTNM9", "021341239" });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "398", true, "address 98", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8460), 198, "7/4/2021 10:19:40 PM", "abcd98@gmail.com", "ABCD98", "MLDS1", null, "OLSTNM98", "0213412398" },
                    { "376", true, "address 76", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6118), 176, "7/4/2021 10:19:40 PM", "abcd76@gmail.com", "ABCD76", "MLDS1", null, "OLSTNM76", "0213412376" },
                    { "375", true, "address 75", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6007), 175, "7/4/2021 10:19:40 PM", "abcd75@gmail.com", "ABCD75", "MLDS1", null, "OLSTNM75", "0213412375" },
                    { "374", true, "address 74", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5883), 174, "7/4/2021 10:19:40 PM", "abcd74@gmail.com", "ABCD74", "MLDS1", null, "OLSTNM74", "0213412374" },
                    { "373", true, "address 73", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5765), 173, "7/4/2021 10:19:40 PM", "abcd73@gmail.com", "ABCD73", "MLDS1", null, "OLSTNM73", "0213412373" },
                    { "372", true, "address 72", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5623), 172, "7/4/2021 10:19:40 PM", "abcd72@gmail.com", "ABCD72", "MLDS1", null, "OLSTNM72", "0213412372" },
                    { "371", true, "address 71", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5386), 171, "7/4/2021 10:19:40 PM", "abcd71@gmail.com", "ABCD71", "MLDS1", null, "OLSTNM71", "0213412371" },
                    { "370", true, "address 70", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5202), 170, "7/4/2021 10:19:40 PM", "abcd70@gmail.com", "ABCD70", "MLDS1", null, "OLSTNM70", "0213412370" },
                    { "377", true, "address 77", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6278), 177, "7/4/2021 10:19:40 PM", "abcd77@gmail.com", "ABCD77", "MLDS1", null, "OLSTNM77", "0213412377" },
                    { "369", true, "address 69", 87, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5071), 169, "7/4/2021 10:19:40 PM", "abcd69@gmail.com", "ABCD69", "MLDS1", null, "OLSTNM69", "0213412369" },
                    { "367", true, "address 67", 85, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4822), 167, "7/4/2021 10:19:40 PM", "abcd67@gmail.com", "ABCD67", "MLDS1", null, "OLSTNM67", "0213412367" },
                    { "366", true, "address 66", 84, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4751), 166, "7/4/2021 10:19:40 PM", "abcd66@gmail.com", "ABCD66", "MLDS1", null, "OLSTNM66", "0213412366" },
                    { "365", true, "address 65", 83, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4654), 165, "7/4/2021 10:19:40 PM", "abcd65@gmail.com", "ABCD65", "MLDS1", null, "OLSTNM65", "0213412365" },
                    { "364", true, "address 64", 82, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4498), 164, "7/4/2021 10:19:40 PM", "abcd64@gmail.com", "ABCD64", "MLDS1", null, "OLSTNM64", "0213412364" },
                    { "363", true, "address 63", 81, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4395), 163, "7/4/2021 10:19:40 PM", "abcd63@gmail.com", "ABCD63", "MLDS1", null, "OLSTNM63", "0213412363" },
                    { "362", true, "address 62", 80, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4333), 162, "7/4/2021 10:19:40 PM", "abcd62@gmail.com", "ABCD62", "MLDS1", null, "OLSTNM62", "0213412362" },
                    { "361", true, "address 61", 79, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4270), 161, "7/4/2021 10:19:40 PM", "abcd61@gmail.com", "ABCD61", "MLDS1", null, "OLSTNM61", "0213412361" },
                    { "368", true, "address 68", 86, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4945), 168, "7/4/2021 10:19:40 PM", "abcd68@gmail.com", "ABCD68", "MLDS1", null, "OLSTNM68", "0213412368" },
                    { "378", true, "address 78", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6426), 178, "7/4/2021 10:19:40 PM", "abcd78@gmail.com", "ABCD78", "MLDS1", null, "OLSTNM78", "0213412378" },
                    { "379", true, "address 79", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6596), 179, "7/4/2021 10:19:40 PM", "abcd79@gmail.com", "ABCD79", "MLDS1", null, "OLSTNM79", "0213412379" },
                    { "380", true, "address 80", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6765), 180, "7/4/2021 10:19:40 PM", "abcd80@gmail.com", "ABCD80", "MLDS1", null, "OLSTNM80", "0213412380" },
                    { "397", true, "address 97", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8331), 197, "7/4/2021 10:19:40 PM", "abcd97@gmail.com", "ABCD97", "MLDS1", null, "OLSTNM97", "0213412397" },
                    { "396", true, "address 96", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8209), 196, "7/4/2021 10:19:40 PM", "abcd96@gmail.com", "ABCD96", "MLDS1", null, "OLSTNM96", "0213412396" },
                    { "395", true, "address 95", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8147), 195, "7/4/2021 10:19:40 PM", "abcd95@gmail.com", "ABCD95", "MLDS1", null, "OLSTNM95", "0213412395" },
                    { "394", true, "address 94", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8086), 194, "7/4/2021 10:19:40 PM", "abcd94@gmail.com", "ABCD94", "MLDS1", null, "OLSTNM94", "0213412394" },
                    { "393", true, "address 93", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8024), 193, "7/4/2021 10:19:40 PM", "abcd93@gmail.com", "ABCD93", "MLDS1", null, "OLSTNM93", "0213412393" },
                    { "392", true, "address 92", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7963), 192, "7/4/2021 10:19:40 PM", "abcd92@gmail.com", "ABCD92", "MLDS1", null, "OLSTNM92", "0213412392" },
                    { "391", true, "address 91", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7901), 191, "7/4/2021 10:19:40 PM", "abcd91@gmail.com", "ABCD91", "MLDS1", null, "OLSTNM91", "0213412391" },
                    { "390", true, "address 90", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7837), 190, "7/4/2021 10:19:40 PM", "abcd90@gmail.com", "ABCD90", "MLDS1", null, "OLSTNM90", "0213412390" },
                    { "389", true, "address 89", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7754), 189, "7/4/2021 10:19:40 PM", "abcd89@gmail.com", "ABCD89", "MLDS1", null, "OLSTNM89", "0213412389" },
                    { "388", true, "address 88", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7515), 188, "7/4/2021 10:19:40 PM", "abcd88@gmail.com", "ABCD88", "MLDS1", null, "OLSTNM88", "0213412388" },
                    { "387", true, "address 87", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7453), 187, "7/4/2021 10:19:40 PM", "abcd87@gmail.com", "ABCD87", "MLDS1", null, "OLSTNM87", "0213412387" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "386", true, "address 86", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7392), 186, "7/4/2021 10:19:40 PM", "abcd86@gmail.com", "ABCD86", "MLDS1", null, "OLSTNM86", "0213412386" },
                    { "385", true, "address 85", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7330), 185, "7/4/2021 10:19:40 PM", "abcd85@gmail.com", "ABCD85", "MLDS1", null, "OLSTNM85", "0213412385" },
                    { "360", true, "address 60", 78, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4207), 160, "7/4/2021 10:19:40 PM", "abcd60@gmail.com", "ABCD60", "MLDS1", null, "OLSTNM60", "0213412360" },
                    { "383", true, "address 83", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7207), 183, "7/4/2021 10:19:40 PM", "abcd83@gmail.com", "ABCD83", "MLDS1", null, "OLSTNM83", "0213412383" },
                    { "382", true, "address 82", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7143), 182, "7/4/2021 10:19:40 PM", "abcd82@gmail.com", "ABCD82", "MLDS1", null, "OLSTNM82", "0213412382" },
                    { "381", true, "address 81", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7059), 181, "7/4/2021 10:19:40 PM", "abcd81@gmail.com", "ABCD81", "MLDS1", null, "OLSTNM81", "0213412381" },
                    { "399", true, "address 99", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8530), 199, "7/4/2021 10:19:40 PM", "abcd99@gmail.com", "ABCD99", "MLDS1", null, "OLSTNM99", "0213412399" },
                    { "384", true, "address 84", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7269), 184, "7/4/2021 10:19:40 PM", "abcd84@gmail.com", "ABCD84", "MLDS1", null, "OLSTNM84", "0213412384" },
                    { "359", true, "address 59", 77, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4145), 159, "7/4/2021 10:19:40 PM", "abcd59@gmail.com", "ABCD59", "MLDS1", null, "OLSTNM59", "0213412359" },
                    { "357", true, "address 57", 75, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4015), 157, "7/4/2021 10:19:40 PM", "abcd57@gmail.com", "ABCD57", "MLDS1", null, "OLSTNM57", "0213412357" },
                    { "331", true, "address 31", 49, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2086), 131, "7/4/2021 10:19:40 PM", "abcd31@gmail.com", "ABCD31", "MLDS1", null, "OLSTNM31", "0213412331" },
                    { "330", true, "address 30", 48, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2025), 130, "7/4/2021 10:19:40 PM", "abcd30@gmail.com", "ABCD30", "MLDS1", null, "OLSTNM30", "0213412330" },
                    { "329", true, "address 29", 47, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1963), 129, "7/4/2021 10:19:40 PM", "abcd29@gmail.com", "ABCD29", "MLDS1", null, "OLSTNM29", "0213412329" },
                    { "328", true, "address 28", 46, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1902), 128, "7/4/2021 10:19:40 PM", "abcd28@gmail.com", "ABCD28", "MLDS1", null, "OLSTNM28", "0213412328" },
                    { "327", true, "address 27", 45, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1841), 127, "7/4/2021 10:19:40 PM", "abcd27@gmail.com", "ABCD27", "MLDS1", null, "OLSTNM27", "0213412327" },
                    { "326", true, "address 26", 44, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1779), 126, "7/4/2021 10:19:40 PM", "abcd26@gmail.com", "ABCD26", "MLDS1", null, "OLSTNM26", "0213412326" },
                    { "325", true, "address 25", 43, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1712), 125, "7/4/2021 10:19:40 PM", "abcd25@gmail.com", "ABCD25", "MLDS1", null, "OLSTNM25", "0213412325" },
                    { "324", true, "address 24", 42, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1604), 124, "7/4/2021 10:19:40 PM", "abcd24@gmail.com", "ABCD24", "MLDS1", null, "OLSTNM24", "0213412324" },
                    { "323", true, "address 23", 41, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1369), 123, "7/4/2021 10:19:40 PM", "abcd23@gmail.com", "ABCD23", "MLDS1", null, "OLSTNM23", "0213412323" },
                    { "322", true, "address 22", 40, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1307), 122, "7/4/2021 10:19:40 PM", "abcd22@gmail.com", "ABCD22", "MLDS1", null, "OLSTNM22", "0213412322" },
                    { "321", true, "address 21", 39, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1245), 121, "7/4/2021 10:19:40 PM", "abcd21@gmail.com", "ABCD21", "MLDS1", null, "OLSTNM21", "0213412321" },
                    { "320", true, "address 20", 38, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1184), 120, "7/4/2021 10:19:40 PM", "abcd20@gmail.com", "ABCD20", "MLDS1", null, "OLSTNM20", "0213412320" },
                    { "319", true, "address 19", 37, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1121), 119, "7/4/2021 10:19:40 PM", "abcd19@gmail.com", "ABCD19", "MLDS1", null, "OLSTNM19", "0213412319" },
                    { "318", true, "address 18", 36, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1059), 118, "7/4/2021 10:19:40 PM", "abcd18@gmail.com", "ABCD18", "MLDS1", null, "OLSTNM18", "0213412318" },
                    { "317", true, "address 17", 35, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(996), 117, "7/4/2021 10:19:40 PM", "abcd17@gmail.com", "ABCD17", "MLDS1", null, "OLSTNM17", "0213412317" },
                    { "316", true, "address 16", 34, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(921), 116, "7/4/2021 10:19:40 PM", "abcd16@gmail.com", "ABCD16", "MLDS1", null, "OLSTNM16", "0213412316" },
                    { "315", true, "address 15", 33, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(788), 115, "7/4/2021 10:19:40 PM", "abcd15@gmail.com", "ABCD15", "MLDS1", null, "OLSTNM15", "0213412315" },
                    { "314", true, "address 14", 32, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(727), 114, "7/4/2021 10:19:40 PM", "abcd14@gmail.com", "ABCD14", "MLDS1", null, "OLSTNM14", "0213412314" },
                    { "313", true, "address 13", 31, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(665), 113, "7/4/2021 10:19:40 PM", "abcd13@gmail.com", "ABCD13", "MLDS1", null, "OLSTNM13", "0213412313" },
                    { "312", true, "address 12", 30, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(603), 112, "7/4/2021 10:19:40 PM", "abcd12@gmail.com", "ABCD12", "MLDS1", null, "OLSTNM12", "0213412312" },
                    { "311", true, "address 11", 29, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(542), 111, "7/4/2021 10:19:40 PM", "abcd11@gmail.com", "ABCD11", "MLDS1", null, "OLSTNM11", "0213412311" },
                    { "332", true, "address 32", 50, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2211), 132, "7/4/2021 10:19:40 PM", "abcd32@gmail.com", "ABCD32", "MLDS1", null, "OLSTNM32", "0213412332" },
                    { "358", true, "address 58", 76, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4082), 158, "7/4/2021 10:19:40 PM", "abcd58@gmail.com", "ABCD58", "MLDS1", null, "OLSTNM58", "0213412358" },
                    { "333", true, "address 33", 51, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2293), 133, "7/4/2021 10:19:40 PM", "abcd33@gmail.com", "ABCD33", "MLDS1", null, "OLSTNM33", "0213412333" },
                    { "335", true, "address 35", 53, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2420), 135, "7/4/2021 10:19:40 PM", "abcd35@gmail.com", "ABCD35", "MLDS1", null, "OLSTNM35", "0213412335" },
                    { "356", true, "address 56", 74, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3878), 156, "7/4/2021 10:19:40 PM", "abcd56@gmail.com", "ABCD56", "MLDS1", null, "OLSTNM56", "0213412356" },
                    { "355", true, "address 55", 73, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3816), 155, "7/4/2021 10:19:40 PM", "abcd55@gmail.com", "ABCD55", "MLDS1", null, "OLSTNM55", "0213412355" },
                    { "354", true, "address 54", 72, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3753), 154, "7/4/2021 10:19:40 PM", "abcd54@gmail.com", "ABCD54", "MLDS1", null, "OLSTNM54", "0213412354" },
                    { "353", true, "address 53", 71, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3691), 153, "7/4/2021 10:19:40 PM", "abcd53@gmail.com", "ABCD53", "MLDS1", null, "OLSTNM53", "0213412353" },
                    { "352", true, "address 52", 70, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3629), 152, "7/4/2021 10:19:40 PM", "abcd52@gmail.com", "ABCD52", "MLDS1", null, "OLSTNM52", "0213412352" },
                    { "351", true, "address 51", 69, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3566), 151, "7/4/2021 10:19:40 PM", "abcd51@gmail.com", "ABCD51", "MLDS1", null, "OLSTNM51", "0213412351" },
                    { "350", true, "address 50", 68, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3504), 150, "7/4/2021 10:19:40 PM", "abcd50@gmail.com", "ABCD50", "MLDS1", null, "OLSTNM50", "0213412350" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "Gender", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "349", true, "address 49", 67, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3440), 149, "7/4/2021 10:19:40 PM", "abcd49@gmail.com", "ABCD49", "MLDS1", null, "OLSTNM49", "0213412349" },
                    { "348", true, "address 48", 66, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3367), 148, "7/4/2021 10:19:40 PM", "abcd48@gmail.com", "ABCD48", "MLDS1", null, "OLSTNM48", "0213412348" },
                    { "347", true, "address 47", 65, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3236), 147, "7/4/2021 10:19:40 PM", "abcd47@gmail.com", "ABCD47", "MLDS1", null, "OLSTNM47", "0213412347" },
                    { "346", true, "address 46", 64, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3174), 146, "7/4/2021 10:19:40 PM", "abcd46@gmail.com", "ABCD46", "MLDS1", null, "OLSTNM46", "0213412346" },
                    { "345", true, "address 45", 63, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3112), 145, "7/4/2021 10:19:40 PM", "abcd45@gmail.com", "ABCD45", "MLDS1", null, "OLSTNM45", "0213412345" },
                    { "344", true, "address 44", 62, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3049), 144, "7/4/2021 10:19:40 PM", "abcd44@gmail.com", "ABCD44", "MLDS1", null, "OLSTNM44", "0213412344" },
                    { "343", true, "address 43", 61, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2987), 143, "7/4/2021 10:19:40 PM", "abcd43@gmail.com", "ABCD43", "MLDS1", null, "OLSTNM43", "0213412343" },
                    { "342", true, "address 42", 60, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2925), 142, "7/4/2021 10:19:40 PM", "abcd42@gmail.com", "ABCD42", "MLDS1", null, "OLSTNM42", "0213412342" },
                    { "341", true, "address 41", 59, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2862), 141, "7/4/2021 10:19:40 PM", "abcd41@gmail.com", "ABCD41", "MLDS1", null, "OLSTNM41", "0213412341" },
                    { "340", true, "address 40", 58, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2789), 140, "7/4/2021 10:19:40 PM", "abcd40@gmail.com", "ABCD40", "MLDS1", null, "OLSTNM40", "0213412340" },
                    { "339", true, "address 39", 57, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2668), 139, "7/4/2021 10:19:40 PM", "abcd39@gmail.com", "ABCD39", "MLDS1", null, "OLSTNM39", "0213412339" },
                    { "338", true, "address 38", 56, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2607), 138, "7/4/2021 10:19:40 PM", "abcd38@gmail.com", "ABCD38", "MLDS1", null, "OLSTNM38", "0213412338" },
                    { "337", true, "address 37", 55, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2544), 137, "7/4/2021 10:19:40 PM", "abcd37@gmail.com", "ABCD37", "MLDS1", null, "OLSTNM37", "0213412337" },
                    { "336", true, "address 36", 54, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2482), 136, "7/4/2021 10:19:40 PM", "abcd36@gmail.com", "ABCD36", "MLDS1", null, "OLSTNM36", "0213412336" },
                    { "334", true, "address 34", 52, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2358), 134, "7/4/2021 10:19:40 PM", "abcd34@gmail.com", "ABCD34", "MLDS1", null, "OLSTNM34", "0213412334" },
                    { "310", true, "address 10", 28, new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(480), 110, "7/4/2021 10:19:40 PM", "abcd10@gmail.com", "ABCD10", "MLDS1", null, "OLSTNM10", "0213412310" }
                });
        }
    }
}
