﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XyiconLK.CodingChallenge.DataAccess.Migrations
{
    public partial class SeedBulkDataMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "3");

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "30", true, "address 0", 18, new DateTime(2021, 7, 4, 22, 14, 58, 392, DateTimeKind.Local).AddTicks(5572), 100, "7/4/2021 10:14:58 PM", "abcd0@gmail.com", "ABCD0", "MLDS1", "OLSTNM0", "021341230" },
                    { "372", true, "address 72", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5650), 172, "7/4/2021 10:14:58 PM", "abcd72@gmail.com", "ABCD72", "MLDS1", "OLSTNM72", "0213412372" },
                    { "371", true, "address 71", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5576), 171, "7/4/2021 10:14:58 PM", "abcd71@gmail.com", "ABCD71", "MLDS1", "OLSTNM71", "0213412371" },
                    { "370", true, "address 70", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5499), 170, "7/4/2021 10:14:58 PM", "abcd70@gmail.com", "ABCD70", "MLDS1", "OLSTNM70", "0213412370" },
                    { "369", true, "address 69", 87, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5346), 169, "7/4/2021 10:14:58 PM", "abcd69@gmail.com", "ABCD69", "MLDS1", "OLSTNM69", "0213412369" },
                    { "368", true, "address 68", 86, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5273), 168, "7/4/2021 10:14:58 PM", "abcd68@gmail.com", "ABCD68", "MLDS1", "OLSTNM68", "0213412368" },
                    { "367", true, "address 67", 85, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5199), 167, "7/4/2021 10:14:58 PM", "abcd67@gmail.com", "ABCD67", "MLDS1", "OLSTNM67", "0213412367" },
                    { "366", true, "address 66", 84, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5129), 166, "7/4/2021 10:14:58 PM", "abcd66@gmail.com", "ABCD66", "MLDS1", "OLSTNM66", "0213412366" },
                    { "365", true, "address 65", 83, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5058), 165, "7/4/2021 10:14:58 PM", "abcd65@gmail.com", "ABCD65", "MLDS1", "OLSTNM65", "0213412365" },
                    { "364", true, "address 64", 82, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4975), 164, "7/4/2021 10:14:58 PM", "abcd64@gmail.com", "ABCD64", "MLDS1", "OLSTNM64", "0213412364" },
                    { "363", true, "address 63", 81, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4901), 163, "7/4/2021 10:14:58 PM", "abcd63@gmail.com", "ABCD63", "MLDS1", "OLSTNM63", "0213412363" },
                    { "362", true, "address 62", 80, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4762), 162, "7/4/2021 10:14:58 PM", "abcd62@gmail.com", "ABCD62", "MLDS1", "OLSTNM62", "0213412362" },
                    { "361", true, "address 61", 79, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4691), 161, "7/4/2021 10:14:58 PM", "abcd61@gmail.com", "ABCD61", "MLDS1", "OLSTNM61", "0213412361" },
                    { "360", true, "address 60", 78, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4619), 160, "7/4/2021 10:14:58 PM", "abcd60@gmail.com", "ABCD60", "MLDS1", "OLSTNM60", "0213412360" },
                    { "359", true, "address 59", 77, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4547), 159, "7/4/2021 10:14:58 PM", "abcd59@gmail.com", "ABCD59", "MLDS1", "OLSTNM59", "0213412359" },
                    { "358", true, "address 58", 76, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4473), 158, "7/4/2021 10:14:58 PM", "abcd58@gmail.com", "ABCD58", "MLDS1", "OLSTNM58", "0213412358" },
                    { "357", true, "address 57", 75, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4401), 157, "7/4/2021 10:14:58 PM", "abcd57@gmail.com", "ABCD57", "MLDS1", "OLSTNM57", "0213412357" },
                    { "356", true, "address 56", 74, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4329), 156, "7/4/2021 10:14:58 PM", "abcd56@gmail.com", "ABCD56", "MLDS1", "OLSTNM56", "0213412356" },
                    { "355", true, "address 55", 73, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4256), 155, "7/4/2021 10:14:58 PM", "abcd55@gmail.com", "ABCD55", "MLDS1", "OLSTNM55", "0213412355" },
                    { "354", true, "address 54", 72, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4171), 154, "7/4/2021 10:14:58 PM", "abcd54@gmail.com", "ABCD54", "MLDS1", "OLSTNM54", "0213412354" },
                    { "353", true, "address 53", 71, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4045), 153, "7/4/2021 10:14:58 PM", "abcd53@gmail.com", "ABCD53", "MLDS1", "OLSTNM53", "0213412353" },
                    { "352", true, "address 52", 70, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3974), 152, "7/4/2021 10:14:58 PM", "abcd52@gmail.com", "ABCD52", "MLDS1", "OLSTNM52", "0213412352" },
                    { "373", true, "address 73", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5721), 173, "7/4/2021 10:14:58 PM", "abcd73@gmail.com", "ABCD73", "MLDS1", "OLSTNM73", "0213412373" },
                    { "351", true, "address 51", 69, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3901), 151, "7/4/2021 10:14:58 PM", "abcd51@gmail.com", "ABCD51", "MLDS1", "OLSTNM51", "0213412351" },
                    { "374", true, "address 74", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5793), 174, "7/4/2021 10:14:58 PM", "abcd74@gmail.com", "ABCD74", "MLDS1", "OLSTNM74", "0213412374" },
                    { "376", true, "address 76", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5940), 176, "7/4/2021 10:14:58 PM", "abcd76@gmail.com", "ABCD76", "MLDS1", "OLSTNM76", "0213412376" },
                    { "397", true, "address 97", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7855), 197, "7/4/2021 10:14:58 PM", "abcd97@gmail.com", "ABCD97", "MLDS1", "OLSTNM97", "0213412397" },
                    { "396", true, "address 96", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7783), 196, "7/4/2021 10:14:58 PM", "abcd96@gmail.com", "ABCD96", "MLDS1", "OLSTNM96", "0213412396" },
                    { "395", true, "address 95", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7706), 195, "7/4/2021 10:14:58 PM", "abcd95@gmail.com", "ABCD95", "MLDS1", "OLSTNM95", "0213412395" },
                    { "394", true, "address 94", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7544), 194, "7/4/2021 10:14:58 PM", "abcd94@gmail.com", "ABCD94", "MLDS1", "OLSTNM94", "0213412394" },
                    { "393", true, "address 93", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7474), 193, "7/4/2021 10:14:58 PM", "abcd93@gmail.com", "ABCD93", "MLDS1", "OLSTNM93", "0213412393" },
                    { "392", true, "address 92", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7402), 192, "7/4/2021 10:14:58 PM", "abcd92@gmail.com", "ABCD92", "MLDS1", "OLSTNM92", "0213412392" },
                    { "391", true, "address 91", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7331), 191, "7/4/2021 10:14:58 PM", "abcd91@gmail.com", "ABCD91", "MLDS1", "OLSTNM91", "0213412391" },
                    { "390", true, "address 90", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7260), 190, "7/4/2021 10:14:58 PM", "abcd90@gmail.com", "ABCD90", "MLDS1", "OLSTNM90", "0213412390" },
                    { "389", true, "address 89", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7189), 189, "7/4/2021 10:14:58 PM", "abcd89@gmail.com", "ABCD89", "MLDS1", "OLSTNM89", "0213412389" },
                    { "388", true, "address 88", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7114), 188, "7/4/2021 10:14:58 PM", "abcd88@gmail.com", "ABCD88", "MLDS1", "OLSTNM88", "0213412388" },
                    { "387", true, "address 87", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7022), 187, "7/4/2021 10:14:58 PM", "abcd87@gmail.com", "ABCD87", "MLDS1", "OLSTNM87", "0213412387" },
                    { "386", true, "address 86", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6732), 186, "7/4/2021 10:14:58 PM", "abcd86@gmail.com", "ABCD86", "MLDS1", "OLSTNM86", "0213412386" },
                    { "385", true, "address 85", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6658), 185, "7/4/2021 10:14:58 PM", "abcd85@gmail.com", "ABCD85", "MLDS1", "OLSTNM85", "0213412385" },
                    { "384", true, "address 84", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6587), 184, "7/4/2021 10:14:58 PM", "abcd84@gmail.com", "ABCD84", "MLDS1", "OLSTNM84", "0213412384" },
                    { "383", true, "address 83", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6516), 183, "7/4/2021 10:14:58 PM", "abcd83@gmail.com", "ABCD83", "MLDS1", "OLSTNM83", "0213412383" },
                    { "382", true, "address 82", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6445), 182, "7/4/2021 10:14:58 PM", "abcd82@gmail.com", "ABCD82", "MLDS1", "OLSTNM82", "0213412382" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "381", true, "address 81", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6373), 181, "7/4/2021 10:14:58 PM", "abcd81@gmail.com", "ABCD81", "MLDS1", "OLSTNM81", "0213412381" },
                    { "380", true, "address 80", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6302), 180, "7/4/2021 10:14:58 PM", "abcd80@gmail.com", "ABCD80", "MLDS1", "OLSTNM80", "0213412380" },
                    { "379", true, "address 79", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6228), 179, "7/4/2021 10:14:58 PM", "abcd79@gmail.com", "ABCD79", "MLDS1", "OLSTNM79", "0213412379" },
                    { "378", true, "address 78", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6139), 178, "7/4/2021 10:14:58 PM", "abcd78@gmail.com", "ABCD78", "MLDS1", "OLSTNM78", "0213412378" },
                    { "377", true, "address 77", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6012), 177, "7/4/2021 10:14:58 PM", "abcd77@gmail.com", "ABCD77", "MLDS1", "OLSTNM77", "0213412377" },
                    { "375", true, "address 75", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5865), 175, "7/4/2021 10:14:58 PM", "abcd75@gmail.com", "ABCD75", "MLDS1", "OLSTNM75", "0213412375" },
                    { "350", true, "address 50", 68, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3830), 150, "7/4/2021 10:14:58 PM", "abcd50@gmail.com", "ABCD50", "MLDS1", "OLSTNM50", "0213412350" },
                    { "349", true, "address 49", 67, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3758), 149, "7/4/2021 10:14:58 PM", "abcd49@gmail.com", "ABCD49", "MLDS1", "OLSTNM49", "0213412349" },
                    { "348", true, "address 48", 66, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3686), 148, "7/4/2021 10:14:58 PM", "abcd48@gmail.com", "ABCD48", "MLDS1", "OLSTNM48", "0213412348" },
                    { "321", true, "address 21", 39, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(498), 121, "7/4/2021 10:14:58 PM", "abcd21@gmail.com", "ABCD21", "MLDS1", "OLSTNM21", "0213412321" },
                    { "320", true, "address 20", 38, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(266), 120, "7/4/2021 10:14:58 PM", "abcd20@gmail.com", "ABCD20", "MLDS1", "OLSTNM20", "0213412320" },
                    { "319", true, "address 19", 37, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(194), 119, "7/4/2021 10:14:58 PM", "abcd19@gmail.com", "ABCD19", "MLDS1", "OLSTNM19", "0213412319" },
                    { "318", true, "address 18", 36, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(121), 118, "7/4/2021 10:14:58 PM", "abcd18@gmail.com", "ABCD18", "MLDS1", "OLSTNM18", "0213412318" },
                    { "317", true, "address 17", 35, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(45), 117, "7/4/2021 10:14:58 PM", "abcd17@gmail.com", "ABCD17", "MLDS1", "OLSTNM17", "0213412317" },
                    { "316", true, "address 16", 34, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9912), 116, "7/4/2021 10:14:58 PM", "abcd16@gmail.com", "ABCD16", "MLDS1", "OLSTNM16", "0213412316" },
                    { "315", true, "address 15", 33, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9841), 115, "7/4/2021 10:14:58 PM", "abcd15@gmail.com", "ABCD15", "MLDS1", "OLSTNM15", "0213412315" },
                    { "314", true, "address 14", 32, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9768), 114, "7/4/2021 10:14:58 PM", "abcd14@gmail.com", "ABCD14", "MLDS1", "OLSTNM14", "0213412314" },
                    { "313", true, "address 13", 31, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9674), 113, "7/4/2021 10:14:58 PM", "abcd13@gmail.com", "ABCD13", "MLDS1", "OLSTNM13", "0213412313" },
                    { "312", true, "address 12", 30, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9529), 112, "7/4/2021 10:14:58 PM", "abcd12@gmail.com", "ABCD12", "MLDS1", "OLSTNM12", "0213412312" },
                    { "311", true, "address 11", 29, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9458), 111, "7/4/2021 10:14:58 PM", "abcd11@gmail.com", "ABCD11", "MLDS1", "OLSTNM11", "0213412311" },
                    { "310", true, "address 10", 28, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9387), 110, "7/4/2021 10:14:58 PM", "abcd10@gmail.com", "ABCD10", "MLDS1", "OLSTNM10", "0213412310" },
                    { "39", true, "address 9", 27, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9316), 109, "7/4/2021 10:14:58 PM", "abcd9@gmail.com", "ABCD9", "MLDS1", "OLSTNM9", "021341239" },
                    { "38", true, "address 8", 26, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9240), 108, "7/4/2021 10:14:58 PM", "abcd8@gmail.com", "ABCD8", "MLDS1", "OLSTNM8", "021341238" },
                    { "37", true, "address 7", 25, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9170), 107, "7/4/2021 10:14:58 PM", "abcd7@gmail.com", "ABCD7", "MLDS1", "OLSTNM7", "021341237" },
                    { "36", true, "address 6", 24, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9100), 106, "7/4/2021 10:14:58 PM", "abcd6@gmail.com", "ABCD6", "MLDS1", "OLSTNM6", "021341236" },
                    { "35", true, "address 5", 23, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9028), 105, "7/4/2021 10:14:58 PM", "abcd5@gmail.com", "ABCD5", "MLDS1", "OLSTNM5", "021341235" },
                    { "34", true, "address 4", 22, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8938), 104, "7/4/2021 10:14:58 PM", "abcd4@gmail.com", "ABCD4", "MLDS1", "OLSTNM4", "021341234" },
                    { "33", true, "address 3", 21, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8731), 103, "7/4/2021 10:14:58 PM", "abcd3@gmail.com", "ABCD3", "MLDS1", "OLSTNM3", "021341233" },
                    { "32", true, "address 2", 20, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8639), 102, "7/4/2021 10:14:58 PM", "abcd2@gmail.com", "ABCD2", "MLDS1", "OLSTNM2", "021341232" },
                    { "31", true, "address 1", 19, new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8027), 101, "7/4/2021 10:14:58 PM", "abcd1@gmail.com", "ABCD1", "MLDS1", "OLSTNM1", "021341231" },
                    { "322", true, "address 22", 40, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(629), 122, "7/4/2021 10:14:58 PM", "abcd22@gmail.com", "ABCD22", "MLDS1", "OLSTNM22", "0213412322" },
                    { "323", true, "address 23", 41, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(704), 123, "7/4/2021 10:14:58 PM", "abcd23@gmail.com", "ABCD23", "MLDS1", "OLSTNM23", "0213412323" },
                    { "324", true, "address 24", 42, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(778), 124, "7/4/2021 10:14:58 PM", "abcd24@gmail.com", "ABCD24", "MLDS1", "OLSTNM24", "0213412324" },
                    { "325", true, "address 25", 43, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(849), 125, "7/4/2021 10:14:58 PM", "abcd25@gmail.com", "ABCD25", "MLDS1", "OLSTNM25", "0213412325" },
                    { "347", true, "address 47", 65, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3611), 147, "7/4/2021 10:14:58 PM", "abcd47@gmail.com", "ABCD47", "MLDS1", "OLSTNM47", "0213412347" },
                    { "346", true, "address 46", 64, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3534), 146, "7/4/2021 10:14:58 PM", "abcd46@gmail.com", "ABCD46", "MLDS1", "OLSTNM46", "0213412346" },
                    { "345", true, "address 45", 63, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3369), 145, "7/4/2021 10:14:58 PM", "abcd45@gmail.com", "ABCD45", "MLDS1", "OLSTNM45", "0213412345" },
                    { "344", true, "address 44", 62, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3298), 144, "7/4/2021 10:14:58 PM", "abcd44@gmail.com", "ABCD44", "MLDS1", "OLSTNM44", "0213412344" },
                    { "343", true, "address 43", 61, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3226), 143, "7/4/2021 10:14:58 PM", "abcd43@gmail.com", "ABCD43", "MLDS1", "OLSTNM43", "0213412343" },
                    { "342", true, "address 42", 60, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3139), 142, "7/4/2021 10:14:58 PM", "abcd42@gmail.com", "ABCD42", "MLDS1", "OLSTNM42", "0213412342" },
                    { "341", true, "address 41", 59, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2967), 141, "7/4/2021 10:14:58 PM", "abcd41@gmail.com", "ABCD41", "MLDS1", "OLSTNM41", "0213412341" },
                    { "340", true, "address 40", 58, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2810), 140, "7/4/2021 10:14:58 PM", "abcd40@gmail.com", "ABCD40", "MLDS1", "OLSTNM40", "0213412340" }
                });

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "LastName", "PhoneNumber" },
                values: new object[,]
                {
                    { "339", true, "address 39", 57, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2649), 139, "7/4/2021 10:14:58 PM", "abcd39@gmail.com", "ABCD39", "MLDS1", "OLSTNM39", "0213412339" },
                    { "338", true, "address 38", 56, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2522), 138, "7/4/2021 10:14:58 PM", "abcd38@gmail.com", "ABCD38", "MLDS1", "OLSTNM38", "0213412338" },
                    { "398", true, "address 98", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(8025), 198, "7/4/2021 10:14:58 PM", "abcd98@gmail.com", "ABCD98", "MLDS1", "OLSTNM98", "0213412398" },
                    { "337", true, "address 37", 55, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2331), 137, "7/4/2021 10:14:58 PM", "abcd37@gmail.com", "ABCD37", "MLDS1", "OLSTNM37", "0213412337" },
                    { "335", true, "address 35", 53, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1853), 135, "7/4/2021 10:14:58 PM", "abcd35@gmail.com", "ABCD35", "MLDS1", "OLSTNM35", "0213412335" },
                    { "334", true, "address 34", 52, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1703), 134, "7/4/2021 10:14:58 PM", "abcd34@gmail.com", "ABCD34", "MLDS1", "OLSTNM34", "0213412334" },
                    { "333", true, "address 33", 51, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1551), 133, "7/4/2021 10:14:58 PM", "abcd33@gmail.com", "ABCD33", "MLDS1", "OLSTNM33", "0213412333" },
                    { "332", true, "address 32", 50, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1448), 132, "7/4/2021 10:14:58 PM", "abcd32@gmail.com", "ABCD32", "MLDS1", "OLSTNM32", "0213412332" },
                    { "331", true, "address 31", 49, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1352), 131, "7/4/2021 10:14:58 PM", "abcd31@gmail.com", "ABCD31", "MLDS1", "OLSTNM31", "0213412331" },
                    { "330", true, "address 30", 48, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1277), 130, "7/4/2021 10:14:58 PM", "abcd30@gmail.com", "ABCD30", "MLDS1", "OLSTNM30", "0213412330" },
                    { "329", true, "address 29", 47, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1136), 129, "7/4/2021 10:14:58 PM", "abcd29@gmail.com", "ABCD29", "MLDS1", "OLSTNM29", "0213412329" },
                    { "328", true, "address 28", 46, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1062), 128, "7/4/2021 10:14:58 PM", "abcd28@gmail.com", "ABCD28", "MLDS1", "OLSTNM28", "0213412328" },
                    { "327", true, "address 27", 45, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(991), 127, "7/4/2021 10:14:58 PM", "abcd27@gmail.com", "ABCD27", "MLDS1", "OLSTNM27", "0213412327" },
                    { "326", true, "address 26", 44, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(920), 126, "7/4/2021 10:14:58 PM", "abcd26@gmail.com", "ABCD26", "MLDS1", "OLSTNM26", "0213412326" },
                    { "336", true, "address 36", 54, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2010), 136, "7/4/2021 10:14:58 PM", "abcd36@gmail.com", "ABCD36", "MLDS1", "OLSTNM36", "0213412336" },
                    { "399", true, "address 99", 32, new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(8106), 199, "7/4/2021 10:14:58 PM", "abcd99@gmail.com", "ABCD99", "MLDS1", "OLSTNM99", "0213412399" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "30");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "31");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "310");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "311");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "312");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "313");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "314");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "315");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "316");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "317");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "318");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "319");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "32");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "320");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "321");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "322");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "323");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "324");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "325");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "326");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "327");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "328");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "329");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "33");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "330");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "331");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "332");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "333");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "334");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "335");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "336");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "337");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "338");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "339");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "34");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "340");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "341");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "342");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "343");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "344");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "345");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "346");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "347");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "348");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "349");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "35");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "350");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "351");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "352");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "353");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "354");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "355");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "356");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "357");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "358");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "359");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "36");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "360");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "361");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "362");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "363");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "364");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "365");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "366");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "367");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "368");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "369");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "37");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "370");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "371");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "372");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "373");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "374");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "375");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "376");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "377");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "378");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "379");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "38");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "380");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "381");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "382");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "383");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "384");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "385");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "386");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "387");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "388");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "389");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "39");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "390");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "391");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "392");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "393");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "394");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "395");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "396");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "397");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "398");

            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "399");

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "LastName", "PhoneNumber" },
                values: new object[] { "3", true, "address 1", 32, new DateTime(2021, 7, 4, 22, 2, 28, 326, DateTimeKind.Local).AddTicks(5959), 100, "7/4/2021 10:02:28 PM", "abcd@gmail.com", "ABCD", "MLDS", "OLSTNM", "021341234" });
        }
    }
}
