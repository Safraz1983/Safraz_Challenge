﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PeoplesInformation.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using XyiconLK.CodingChallenge.Configuration;
using XyiconLK.CodingChallenge.DataAccess;
using XyiconLK.CodingChallenge.DataAccess.LogWriter;
using XyiconLK.CodingChallenge.Models;

namespace XyiconLK.CodingChallenge.Controllers
{


    public class DataController : Controller
    {
        [HttpGet]
        [Route("api/people")]
        public ActionResult<List<PersonViewModel>> GetAll()
        {
            List<PersonViewModel> personsViewModelList = new List<PersonViewModel>();
            try
            {
                DbContextOptions<PersonContext> option = new DbContextOptions<PersonContext>();
                using (PersonContext context = new PersonContext(option))
                {
                    List<Person> personList = context.Person.ToList();
                    var foreignVisits = context.ForeignVisit.ToList();
                    IEnumerable<ForeignVisitViewModel> resultForeignVisits = from s in foreignVisits select (new ForeignVisitViewModel { 
                        ID = s.ID
                        ,City=s.City
                        ,Country=s.Country
                        ,VisitedYear=s.VisitedYear
                    });

                    IEnumerable<PersonViewModel> resultPersonList =from s in personList select(new PersonViewModel {  
                     ID=s.ID.ToString()
                    ,Address=s.Address
                    ,Age=s.Age
                    ,BirthDate=s.BirthDate
                    ,Email=s.Email
                    ,FirstName=s.FirstName
                    ,FullName=s.FullName
                    ,LastName=s.LastName
                    ,PhoneNumber=s.PhoneNumber
                    ,ForeignVisits=(from a in resultForeignVisits where a.ID.ToString()==s.ID select a).ToList()
                    });

                    personsViewModelList = resultPersonList.ToList();
                }
                

                
            }
            catch (Exception ex)
            {

                LogWriter.LogWrite("Error : " + ex);
            }
            return personsViewModelList;
        }
        /// <summary>
        /// Gettting the developer data from the configuration class function.
        /// url routed as api/about
        /// </summary>
        /// <returns>Developer view model object</returns>
        [HttpGet]
        [Route("api/about")]
        public ActionResult<DeveloperViewModel> GetDeveloper()
        {
            DeveloperViewModel developerData = new DeveloperViewModel();
            try
            {
                var devConfig = CodingChallengeConfiguration.GetDeveloperDetails();
                string devName = devConfig.Name;
                string devEmail = devConfig.Email;

                developerData = new DeveloperViewModel()
                {
                    Email = devEmail,
                    Name = devName,
                    Timestamp = System.DateTime.UtcNow
                };
            }
            catch (Exception ex)
            {
                LogWriter.LogWrite("Error : "+ex);
            }
            return developerData;

        }
    }
}
