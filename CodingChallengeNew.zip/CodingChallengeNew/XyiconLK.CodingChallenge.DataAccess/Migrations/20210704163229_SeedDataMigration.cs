﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XyiconLK.CodingChallenge.DataAccess.Migrations
{
    public partial class SeedDataMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Active",
                table: "ForeignVisit",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.InsertData(
                table: "Person",
                columns: new[] { "ID", "Active", "Address", "Age", "BirthDate", "CreatedBy", "CreatedDate", "Email", "FirstName", "FullName", "LastName", "PhoneNumber" },
                values: new object[] { "3", true, "address 1", 32, new DateTime(2021, 7, 4, 22, 2, 28, 326, DateTimeKind.Local).AddTicks(5959), 100, "7/4/2021 10:02:28 PM", "abcd@gmail.com", "ABCD", "MLDS", "OLSTNM", "021341234" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "3");

            migrationBuilder.DropColumn(
                name: "Active",
                table: "ForeignVisit");
        }
    }
}
