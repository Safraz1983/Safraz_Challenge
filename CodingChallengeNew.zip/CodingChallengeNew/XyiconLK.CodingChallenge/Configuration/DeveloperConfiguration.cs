﻿namespace XyiconLK.CodingChallenge.Configuration
{
    public class DeveloperConfiguration
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
