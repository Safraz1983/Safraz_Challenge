﻿using System;

namespace XyiconLK.CodingChallenge.Models
{
    public class DeveloperViewModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
