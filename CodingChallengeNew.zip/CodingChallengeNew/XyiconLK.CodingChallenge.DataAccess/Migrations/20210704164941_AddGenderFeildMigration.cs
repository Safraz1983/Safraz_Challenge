﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XyiconLK.CodingChallenge.DataAccess.Migrations
{
    public partial class AddGenderFeildMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "Person",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "30",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 128, DateTimeKind.Local).AddTicks(991), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "31",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9269), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "310",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(480), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "311",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(542), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "312",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(603), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "313",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(665), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "314",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(727), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "315",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(788), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "316",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(921), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "317",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(996), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "318",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1059), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "319",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1121), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "32",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9790), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "320",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1184), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "321",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1245), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "322",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1307), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "323",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1369), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "324",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1604), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "325",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1712), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "326",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1779), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "327",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1841), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "328",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1902), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "329",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(1963), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "33",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9874), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "330",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2025), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "331",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2086), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "332",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2211), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "333",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2293), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "334",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2358), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "335",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2420), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "336",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2482), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "337",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2544), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "338",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2607), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "339",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2668), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "34",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 134, DateTimeKind.Local).AddTicks(9939), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "340",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2789), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "341",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2862), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "342",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2925), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "343",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(2987), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "344",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3049), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "345",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3112), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "346",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3174), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "347",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3236), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "348",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3367), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "349",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3440), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "35",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(15), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "350",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3504), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "351",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3566), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "352",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3629), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "353",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3691), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "354",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3753), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "355",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3816), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "356",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(3878), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "357",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4015), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "358",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4082), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "359",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4145), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "36",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(77), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "360",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4207), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "361",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4270), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "362",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4333), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "363",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4395), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "364",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4498), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "365",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4654), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "366",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4751), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "367",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4822), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "368",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(4945), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "369",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5071), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "37",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(275), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "370",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5202), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "371",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5386), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "372",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5623), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "373",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5765), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "374",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(5883), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "375",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6007), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "376",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6118), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "377",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6278), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "378",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6426), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "379",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6596), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "38",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(352), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "380",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(6765), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "381",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7059), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "382",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7143), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "383",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7207), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "384",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7269), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "385",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7330), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "386",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7392), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "387",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7453), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "388",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7515), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "389",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7754), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "39",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(418), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "390",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7837), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "391",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7901), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "392",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(7963), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "393",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8024), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "394",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8086), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "395",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8147), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "396",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8209), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "397",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8331), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "398",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8460), "7/4/2021 10:19:40 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "399",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 19, 40, 135, DateTimeKind.Local).AddTicks(8530), "7/4/2021 10:19:40 PM" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Person");

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "30",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 392, DateTimeKind.Local).AddTicks(5572), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "31",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8027), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "310",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9387), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "311",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9458), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "312",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9529), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "313",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9674), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "314",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9768), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "315",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9841), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "316",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9912), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "317",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(45), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "318",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(121), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "319",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(194), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "32",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8639), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "320",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(266), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "321",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(498), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "322",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(629), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "323",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(704), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "324",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(778), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "325",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(849), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "326",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(920), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "327",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(991), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "328",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1062), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "329",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1136), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "33",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8731), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "330",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1277), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "331",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1352), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "332",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1448), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "333",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1551), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "334",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1703), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "335",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(1853), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "336",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2010), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "337",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2331), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "338",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2522), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "339",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2649), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "34",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(8938), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "340",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2810), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "341",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(2967), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "342",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3139), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "343",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3226), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "344",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3298), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "345",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3369), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "346",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3534), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "347",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3611), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "348",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3686), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "349",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3758), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "35",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9028), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "350",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3830), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "351",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3901), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "352",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(3974), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "353",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4045), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "354",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4171), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "355",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4256), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "356",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4329), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "357",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4401), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "358",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4473), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "359",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4547), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "36",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9100), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "360",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4619), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "361",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4691), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "362",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4762), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "363",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4901), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "364",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(4975), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "365",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5058), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "366",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5129), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "367",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5199), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "368",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5273), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "369",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5346), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "37",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9170), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "370",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5499), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "371",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5576), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "372",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5650), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "373",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5721), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "374",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5793), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "375",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5865), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "376",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(5940), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "377",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6012), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "378",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6139), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "379",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6228), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "38",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9240), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "380",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6302), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "381",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6373), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "382",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6445), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "383",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6516), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "384",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6587), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "385",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6658), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "386",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(6732), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "387",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7022), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "388",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7114), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "389",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7189), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "39",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 400, DateTimeKind.Local).AddTicks(9316), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "390",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7260), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "391",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7331), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "392",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7402), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "393",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7474), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "394",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7544), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "395",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7706), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "396",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7783), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "397",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(7855), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "398",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(8025), "7/4/2021 10:14:58 PM" });

            migrationBuilder.UpdateData(
                table: "Person",
                keyColumn: "ID",
                keyValue: "399",
                columns: new[] { "BirthDate", "CreatedDate" },
                values: new object[] { new DateTime(2021, 7, 4, 22, 14, 58, 401, DateTimeKind.Local).AddTicks(8106), "7/4/2021 10:14:58 PM" });
        }
    }
}
