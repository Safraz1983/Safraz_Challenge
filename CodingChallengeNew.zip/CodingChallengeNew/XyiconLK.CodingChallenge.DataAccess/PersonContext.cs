﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XyiconLK.CodingChallenge.DataAccess;

namespace PeoplesInformation.DAL
{
    public class PersonContext : DbContext
    {
        public PersonContext(DbContextOptions<PersonContext> options) : base(options)
        {

        }
        public DbSet<Person> Person { get; set; }
        public DbSet<ForeignVisit> ForeignVisit { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=XyiconLKCodeChallengeDB2;Trusted_Connection=True;");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            for (int i = 1; i < 100; i++)
            {
                modelBuilder.Entity<Person>().HasData(
                                new Person
                                {
                                    FirstName = "ABCD" + i
                                ,
                                    Address = "address " + i
                                ,
                                    Active = true
                                ,
                                    Age = i < 70 ? 18 + i : 32
                                ,
                                    BirthDate = DateTime.Now
                                ,
                                    CreatedBy = 100 + i
                                ,
                                    CreatedDate = System.DateTime.Now.ToString()
                                ,
                                    Email = "abcd" + i + "@gmail.com"
                                ,
                                    FullName = "MLDS" + 1
                                ,
                                    LastName = "OLSTNM" + i
                                ,
                                    PhoneNumber = "02134123" + i
                                ,
                                    ID = i.ToString()
                                }
                                );


            }

            
                modelBuilder.Entity<ForeignVisit>().HasData(
                   new ForeignVisit
                   {
                       ID = 1
                       ,
                       PersonID = 1
                       ,
                       City = "CMB"
                       ,
                       Country = "SLK"
                       ,
                       VisitedYear = 2019
                       ,
                       Active = true
                       ,
                       CreatedBy = 100
                       ,
                       CreatedOn = System.DateTime.Now
                   });
            



        }
    }
}
