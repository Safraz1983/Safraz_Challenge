﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using XyiconLK.CodingChallenge.DataAccess.LogWriter;

namespace XyiconLK.CodingChallenge.Configuration
{
    public static class CodingChallengeConfiguration
    {
      
        public static DeveloperConfiguration Developer { get; set; }

       

        /// <summary>
        /// Gettting the developer information from the appsettings file.
        /// </summary>
        /// <returns></returns>
        public static DeveloperConfiguration GetDeveloperDetails()
        {
            try
            {
                Developer = new DeveloperConfiguration();

                var developerConfiguraionList = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json").Build().GetSection("Developer");

                string developerName = developerConfiguraionList["Name"].ToString();
                string developerEmail = developerConfiguraionList["Email"].ToString();

                Developer.Name = developerName;
                Developer.Email = developerEmail;

                
            }
            catch (Exception ex)
            {

                LogWriter.LogWrite("Error : " + ex);
            }
            return Developer;
        }

       
    }
}
