﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace XyiconLK.CodingChallenge.DataAccess
{
    public class ForeignVisit
    {
        [Key]
        public int ID { get; set; }
        public int PersonID { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public int VisitedYear { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool Active { get; set; }
    }
}
