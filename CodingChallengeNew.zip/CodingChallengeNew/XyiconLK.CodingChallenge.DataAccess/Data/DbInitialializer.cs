﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PeoplesInformation.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XyiconLK.CodingChallenge.DataAccess.Migrations;

namespace XyiconLK.CodingChallenge.DataAccess.Data
{
    public class DbInitialializer : IDBInitializer
    {
        private readonly PersonContext _personDb;
        
        public DbInitialializer(PersonContext personDb)
        {
            _personDb = personDb;
        }

        /// <summary>
        /// Using this to migrate the database if it not synced.
        /// </summary>
        public void initialize()
        {
            
            try
            {
                if (_personDb.Database.GetPendingMigrations().Count() > 0)
                {
                    _personDb.Database.Migrate();
                    
                }

            }
            catch (Exception ex)
            {
                LogWriter.LogWriter.LogWrite("Error : " + ex);
                
            }
        }
    }
}
