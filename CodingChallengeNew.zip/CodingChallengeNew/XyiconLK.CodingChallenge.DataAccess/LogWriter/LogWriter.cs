﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace XyiconLK.CodingChallenge.DataAccess.LogWriter
{
    public static class LogWriter
    {
              
            private static string logPath = string.Empty;

        /// <summary>
        /// creating the directory and files and calling the method to write the logs.
        /// </summary>
        /// <param name="logMessage"></param>
        public static void LogWrite(string logMessage)
        {
            string distinationDirectory = Directory.GetCurrentDirectory() + "\\XyconLKLogs";
            if(!Directory.Exists(distinationDirectory))
                 Directory.CreateDirectory(distinationDirectory);

            logPath = Path.GetDirectoryName(Directory.GetCurrentDirectory() + "\\XyconLKLogs");
            string filePath = logPath+ "\\XyconLKLogs" + "\\log.txt";
            
            try
            {
                
                using (FileStream fileStream = new FileStream(filePath, FileMode.Append))
                {
                     
                    using (StreamWriter log = new StreamWriter(fileStream))
                    {
                        AppendLog(logMessage, log);
                    }
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        /// <summary>
        /// using the tex writer and message input and writing the to content
        /// </summary>
        /// <param name="logMessage"></param>
        /// <param name="txtWriter"></param>
        private static void AppendLog(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1} {2}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString(), logMessage);               
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}

